#!/bin/bash
# Get local timezone timestamp in format: YYYY-MM-DD_HH:MM.SS
date '+%Y-%m-%d_%H:%M.%S'
